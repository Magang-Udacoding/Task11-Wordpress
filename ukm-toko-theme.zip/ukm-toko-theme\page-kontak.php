<?php
/**
 * Template Name: Halaman Kontak Toko - Retro Contact Us
 *
 * @package UKM_Toko_Theme
 */

get_header();

$wa_number = get_theme_mod('ukm_wa_number', '6281234567890');
$wa_clean  = preg_replace('/[^0-9]/', '', $wa_number);
$address   = get_theme_mod('ukm_store_address', 'Jl. Merdeka No. 45, Sentra UKM Kota Bandung, Jawa Barat');
$wa_url    = 'https://wa.me/' . $wa_clean . '?text=' . rawurlencode('Halo Admin Toko Berkah, saya ingin berkonsultasi seputar pesanan sembako.');
?>

<main id="primary-content" class="contact-page-main">
    <div class="site-container">

        <!-- Breadcrumbs -->
        <div class="retro-breadcrumbs">
            <a href="<?php echo esc_url(home_url('/')); ?>">&larr; Beranda</a>
            <span class="bc-sep">/</span>
            <span class="bc-current">Kontak Toko</span>
        </div>

        <!-- Hero Header -->
        <div class="contact-hero-card">
            <div class="contact-badge-pill">
                <span>[LAYANAN KONSUMEN & KEMITRAAN WARUNG]</span>
            </div>
            <h1 class="contact-main-title">Hubungi Tim Layanan Pelanggan Toko Berkah</h1>
            <p class="contact-main-subtitle">
                Ada pertanyaan seputar ketersediaan stok, harga grosir sembako karungan, pengiriman same-day kurir toko, atau pendaftaran kemitraan warung? Kami siap melayani dengan cepat dan transparan.
            </p>
        </div>

        <!-- 2-Column Contact Layout -->
        <div class="contact-grid-layout">
            
            <!-- LEFT: Contact Form -->
            <div class="contact-form-column">
                <div class="retro-box-card">
                    <div class="retro-card-header">
                        <span class="retro-step-num">&equiv;</span>
                        <div>
                            <h2 class="retro-card-title">Kirim Pesan / Permintaan Pasokan</h2>
                            <small>Isi formulir di bawah ini, admin toko akan segera merespons</small>
                        </div>
                    </div>

                    <form class="retro-form" id="tokoContactForm" onsubmit="event.preventDefault(); alert('Terima kasih! Pesan Anda telah diterima oleh Admin Toko Berkah. Staf kami akan segera menghubungi nomor WhatsApp Anda.'); this.reset();">
                        <div class="form-row-2">
                            <div class="form-group">
                                <label for="cName">Nama Lengkap <span class="req">*</span></label>
                                <input type="text" id="cName" class="retro-input" required placeholder="Contoh: Ibu Rina / Pak Budi" />
                            </div>
                            <div class="form-group">
                                <label for="cPhone">Nomor WhatsApp / HP <span class="req">*</span></label>
                                <input type="tel" id="cPhone" class="retro-input" required placeholder="Contoh: 081234567890" />
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="cTopic">Tujuan Keperluan <span class="req">*</span></label>
                            <select id="cTopic" class="retro-input" style="height:44px;">
                                <option value="retail">Pemesanan Sembako Rumah Tangga (Eceran)</option>
                                <option value="grosir">Pemesanan Grosir / Usaha Kuliner & Restoran</option>
                                <option value="mitra">Pendaftaran Program Kemitraan Warung Binaan</option>
                                <option value="konfirmasi">Konfirmasi Pembayaran & Cek Status Pengiriman</option>
                                <option value="lainnya">Pertanyaan Umum / Kerjasama Lainnya</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="cMessage">Rincian Kebutuhan Sembako atau Pertanyaan <span class="req">*</span></label>
                            <textarea id="cMessage" class="retro-textarea" rows="4" required placeholder="Tuliskan daftar pesanan sembako atau pertanyaan Anda di sini..."></textarea>
                        </div>

                        <button type="submit" class="retro-btn-cta-black" style="width:100%; padding:14px; text-align:center; font-size:15px; cursor:pointer;">
                            Kirim Pesan ke Admin &rarr;
                        </button>
                    </form>
                </div>
            </div>

            <!-- RIGHT: Direct Contact Info & Store Details -->
            <div class="contact-info-column">
                
                <!-- Quick WhatsApp Card -->
                <div class="retro-box-card">
                    <div class="retro-card-header">
                        <span class="retro-step-num">&phone;</span>
                        <div>
                            <h2 class="retro-card-title">Respon Kilat via WhatsApp</h2>
                            <small>Chat langsung dengan customer service kami</small>
                        </div>
                    </div>
                    <div class="retro-card-body">
                        <p style="font-size:14px; line-height:1.6; margin:0 0 16px 0;">
                            Dapatkan konfirmasi stok beras hari ini, penawaran harga grosir karungan, dan koordinasi jam pengiriman pesanan secara instan.
                        </p>
                        <a href="<?php echo esc_url($wa_url); ?>" target="_blank" rel="noopener noreferrer" class="retro-btn-cta-black" style="display:block; text-align:center; padding:12px;">
                            Chat WhatsApp: +<?php echo esc_html($wa_clean); ?> &rarr;
                        </a>
                    </div>
                </div>

                <!-- Store Warehouse Card -->
                <div class="retro-box-card">
                    <div class="retro-card-header">
                        <span class="retro-step-num">&sect;</span>
                        <div>
                            <h2 class="retro-card-title">Gudang & Titik Distribusi</h2>
                            <small>Lokasi operasional Toko Berkah</small>
                        </div>
                    </div>
                    
                    <div class="store-details-list">
                        <div class="store-info-row">
                            <strong class="info-label">[ALAMAT GUDANG]</strong>
                            <p><?php echo esc_html($address); ?></p>
                        </div>

                        <div class="store-info-row">
                            <strong class="info-label">[JAM OPERASIONAL]</strong>
                            <p>Senin - Minggu: 07:00 - 21:00 WIB (Buka setiap hari melayani pengiriman).</p>
                        </div>

                        <div class="store-info-row">
                            <strong class="info-label">[JANGKAUAN KURIR]</strong>
                            <p>Seluruh Kota Bandung, Cimahi, Kab. Bandung & Bandung Barat (Same-Day Delivery).</p>
                        </div>

                        <div class="store-info-row">
                            <strong class="info-label">[METODE PEMBAYARAN]</strong>
                            <p>QRIS Semua Bank & E-Wallet, Transfer BCA / Mandiri, serta COD (Bayar di Tempat).</p>
                        </div>
                    </div>
                </div>

            </div>

        </div>

        <!-- FAQ Section -->
        <div class="contact-faq-section">
            <div class="faq-header-card">
                <span class="faq-badge">[TANYA JAWAB RESMI]</span>
                <h2 class="faq-section-title">Pertanyaan yang Sering Diajukan (FAQ)</h2>
            </div>

            <div class="faq-cards-grid">
                <div class="retro-box-card faq-card">
                    <h4>Berapa minimal pembelian sembako di Toko Berkah?</h4>
                    <p>Tidak ada batas minimal pembelian! Anda dapat memesan 1 bungkus gula kristal atau 1 botol minyak goreng sekalipun. Untuk fasilitas gratis ongkos kirim, berlaku dengan belanja minimal Rp 50.000.</p>
                </div>
                <div class="retro-box-card faq-card">
                    <h4>Kapan pesanan saya diantar ke alamat?</h4>
                    <p>Pesanan yang diverifikasi sebelum pukul 17:00 WIB diantar di hari yang sama (Same-Day). Pesanan setelah jam 17:00 dijadwalkan pada pengiriman pertama esok pagi.</p>
                </div>
                <div class="retro-box-card faq-card">
                    <h4>Bagaimana cara mendaftar jadi Mitra Warung Binaan?</h4>
                    <p>Pendaftaran mitra warung 100% gratis. Cukup hubungi admin via WhatsApp dengan melampirkan foto kios warung Anda, tim kami akan mengaktifkan daftar harga khusus grosir.</p>
                </div>
                <div class="retro-box-card faq-card">
                    <h4>Apakah kualitas timbangan dijamin akurat?</h4>
                    <p>Pasti! Kami menggunakan timbangan digital tersertifikasi berkala. Jika saat diterima berat beras atau gula berkurang, kami ganti selisihnya seketika tanpa biaya tambahan.</p>
                </div>
            </div>
        </div>

    </div>
</main>

<?php
get_footer();
